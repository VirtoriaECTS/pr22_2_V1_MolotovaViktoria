package com.example.pract20_2_molotova

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.asLiveData
import kotlinx.coroutines.*


class StatisticsScreen : AppCompatActivity() {
    var users = ArrayList<String>()


    private val dataList = mutableListOf<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics_screen)
        printInfo()

    }


    private fun printInfo() {
        val textList = findViewById<ListView>(R.id.listView)
        dataList.clear()

        val db = MainDb.getDb(this)

        db.getDao().getAllItem().asLiveData().observe(this) { list ->
            val updatedDataList = mutableListOf<Item>()
            list.forEach { item ->
                val text = "id ${item.id}, type ${item.type} number ${item.number} fact ${item.fact} \n"
                // Создайте новый элемент Item и добавьте его в dataList
                val newItem = Item(id = item.id, type = item.type, number = item.number, fact = item.fact)
                updatedDataList.add(newItem)
            }

            // После завершения цикла, обновите dataList
            dataList.clear()
            dataList.addAll(updatedDataList)

            // Создайте или обновите адаптер
            val itemAdapter = ItemAdapter(this, dataList,
                onDeleteClick = { itemToDelete ->
                    // Здесь выполняйте удаление элемента из базы данных и обновление списка
                    val db = MainDb.getDb(this)
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            db.getDao().deleteItem(itemToDelete)
                            // После удаления, обновите список данных
                            printInfo()
                        } catch (e: Exception) {
                            // Обработка ошибки удаления, если произошла
                        }
                    }
                    printInfo()
                    printInfo()
                },
                onEditClick = { position ->
                    // Получаю рание данные
                    val db = MainDb.getDb(this)
                    var bdNewText: Array<String> = arrayOf("id", "type", "number", "fact")
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            bdNewText= arrayOf(position.id.toString(), position.type, position.number, position.fact)
                        } catch (e: Exception) {
                            // Обработка ошибки удаления, если произошла
                        }
                    }
                    //изменения через AlertDiolog
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Измените данные")

                    // Создайте контейнер LinearLayout для размещения двух EditText
                    val layout = LinearLayout(this)
                    layout.orientation = LinearLayout.VERTICAL

                    // Создайте два EditText для ввода данных
                    val EditNumber = EditText(this)
                    val EditFakt = EditText(this)

                    // Установите хинты для EditText
                    EditNumber.hint = "Введите дату или год"
                    EditFakt.hint = "Введите факт"
                    EditNumber.setText(bdNewText[2])
                    EditFakt.setText(bdNewText[3])
                    // Добавьте EditText к контейнеру
                    layout.addView(EditNumber)
                    layout.addView(EditFakt)

                    builder.setView(layout)

                    // Установите кнопку "OK" для сохранения данных
                    builder.setPositiveButton("OK") { dialog, _ ->
                        var number = EditNumber.text.toString()
                        var fakt = EditFakt.text.toString()


                        //запись в бд
                        //проверка
                        if(number.isEmpty()){
                            number = bdNewText[2];
                        }
                        if(fakt.isEmpty()){
                            fakt = bdNewText[3];
                        }
                        //сама запись
                        val item = Item(bdNewText[0].toInt(), "null", number, fakt)
                        CoroutineScope(Dispatchers.IO).launch {
                            // Вызовите suspend-функцию updateItem в корутине
                            db.getDao().updateItem(item)
                        }
                        printInfo()

                    }

                    // Установите кнопку "Отмена" для закрытия диалога
                    builder.setNegativeButton("Отмена") { dialog, _ ->
                        dialog.cancel()
                    }

                    val dialog = builder.create()
                    dialog.show()
                    printInfo()

                })
            textList.adapter = itemAdapter

            // Уведомите адаптер о изменениях
            itemAdapter.notifyDataSetChanged()

        }
    }

    fun ButCleaAll(view: View) {
        val db = MainDb.getDb(this)
        CoroutineScope(Dispatchers.IO).launch {
            // Очистите все таблицы в базе данных
            db.clearAllTables()

            // После удаления данных, выполните операции обновления UI на главном потоке (если необходимо)
            withContext(Dispatchers.Main) {
                // Обновление UI, если необходимо
            }
        }
        printInfo()
    }
    fun AddNewButton(view: View) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Введите данные")

        // Создайте контейнер LinearLayout для размещения двух EditText
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        // Создайте два EditText для ввода данных
        val EditNumber = EditText(this)
        val EditFakt = EditText(this)

        // Установите хинты для EditText
        EditNumber.hint = "Введите дату или год"
        EditFakt.hint = "Введите факт"

        // Добавьте EditText к контейнеру
        layout.addView(EditNumber)
        layout.addView(EditFakt)

        builder.setView(layout)

        // Установите кнопку "OK" для сохранения данных
        builder.setPositiveButton("OK") { dialog, _ ->
            val number = EditNumber.text.toString()
            val fakt = EditFakt.text.toString()

            // Здесь можно обработать введенные данные (value1 и value2)
            //запись в бд
            if(number.length == 0 || fakt.length == 0){
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Не сохранено")
                        .setMessage("Необходимо заполнить все поля")
                    .setPositiveButton("ОК") {
                            dialog, id ->  dialog.cancel()
                    }
                builder.create()
            }
            else{
                //сама запись
                val db = MainDb.getDb(this)
                val item = Item(null, "null", number, fakt)
                Thread{
                    db.getDao().insertItem(item)
                }.start()
                dialog.dismiss()
                printInfo()
            }

        }

        // Установите кнопку "Отмена" для закрытия диалога
        builder.setNegativeButton("Отмена") { dialog, _ ->
            dialog.cancel()
        }

        val dialog = builder.create()
        dialog.show()

    }



}