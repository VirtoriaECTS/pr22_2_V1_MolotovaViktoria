package com.example.pract20_2_molotova
import androidx.room.*
import androidx.room.Dao
import kotlinx.coroutines.flow.Flow

@Dao
interface Dao {
    //запись
    @Insert
    fun insertItem(item: Item)

    //получение всех
    @Query("SELECT * FROM items")
    fun getAllItem(): Flow<List<Item>>

    @Delete
    suspend fun deleteItem(item: Item)

    @Update
    suspend fun updateItem(item: Item)
}