package com.example.pract20_2_molotova

import android.app.DownloadManager.Request
import android.content.Intent

import android.os.Bundle
import java.time.Year
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

import androidx.appcompat.app.AppCompatActivity

import android.content.Context

import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.util.Calendar
import android.app.Dialog
import android.os.Build
import androidx.annotation.RequiresApi

import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import java.text.SimpleDateFormat
import java.util.Date
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

class InfoScreen : AppCompatActivity() {
    var YearAndDate:String = "date"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info_screen)



    }


fun findDataAndYear(){
    val shapeSpinner = findViewById<Spinner>(R.id.vibor)

    shapeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            when (shapeSpinner.selectedItem.toString()) {
                "Дата" -> {
                    YearAndDate = "date"
                }
                "Год" -> {
                    YearAndDate = "year"
                }
            }

        }
        override fun onNothingSelected(parent: AdapterView<*>?) {

        }
    }

}


    private fun getResualt(number: String, search: String)
    {
        findDataAndYear()

        val url = "http://numbersapi.com/$number/$search"

        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(
            com.android.volley.Request.Method.GET, url,
            { response ->
                val textInfoSet : TextView= findViewById(R.id.TextInfoSet)
                //val txt = JSONObject(response)
                textInfoSet.text = response.toString()

                //запись в бд

                //тип
                val type: String = "year"

                //число
                val numberTextElement: EditText= findViewById(R.id.EditNumber)
                val numberText = numberTextElement.text.toString()


                //факт
                val fact = response.toString()

                //сама запись
                val db = MainDb.getDb(this)
                val item = Item(null, type, number, fact)
                Thread{
                    db.getDao().insertItem(item)
                }.start()



                Log.d("MyLog", "Volley: $response")
            },
            { error ->



                Log.d("MyLog", "Volley error: ${error.message}")
            })

        queue.add(stringRequest)

    }


    fun cheakYear(yearStr: String): Boolean {
        //текущий год
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        //проверка
        return yearStr.toIntOrNull()?.let { it in 1..year} ?: false
    }
    fun cheakDate(dateStr: String): Boolean {
        val dateFormat = SimpleDateFormat("MM/dd")
        dateFormat.isLenient = false // Отключаем режим допускающий нестрогую проверку

        return try {
            val date = dateFormat.parse(dateStr)
            date != null
        } catch (e: Exception) {
            false
        }
    }


    //нажатие кнопки

    fun ButFindInfo(view: View) {

        findDataAndYear()
    val NumberText = findViewById<EditText>(R.id.EditNumber)

    if((YearAndDate == "date"&& cheakDate(NumberText.text.toString())))
    {
        getResualt(NumberText.text.toString(), YearAndDate)
    }
    else{
        if((YearAndDate == "year"&& cheakYear(NumberText.text.toString())))
        {
            getResualt(NumberText.text.toString(), YearAndDate)
        }
        else{
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Ошибка")
            builder.setMessage("Неверно введенные данные")
            builder.setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }

            val alertDialog = builder.create()
            alertDialog.show()
        }

    }
        val b: Boolean = cheakDate(NumberText.text.toString())
        val t: String = NumberText.text.toString() + " " + b.toString() + " " + YearAndDate + "дата ппустая"
        Log.d("MyLog", t)



    }

    fun Perehod(view: View) {
        val intent = Intent(this, StatisticsScreen::class.java)
        startActivity(intent)
    }
}