package com.example.pract20_2_molotova

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class item_list_row : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_list_row)
    }
}