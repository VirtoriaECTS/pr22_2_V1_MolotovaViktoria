package com.example.pract20_2_molotova

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity (tableName = "items")

//коллоны
data class Item(

    //ид
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null,

    //тип
    @ColumnInfo(name = "type")
    var type: String,

    //число
    @ColumnInfo(name = "number")
    var number: String,

    //факт
    @ColumnInfo(name = "fact")
    var fact: String
    )