package com.example.pract20_2_molotova

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle


import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentTransaction


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPreferences.edit()

        editor.putString("username", "11111")
        editor.putString("password", "11111")
        editor.apply()
    }

    fun nextScreen(view: View) {
        val usernameEditText = findViewById<EditText>(R.id.login)
        val passwordEditText = findViewById<EditText>(R.id.password)

        val log :String = usernameEditText.text.toString()
        val pas:String = passwordEditText.text.toString()

        if (usernameEditText.text.toString().isEmpty() || passwordEditText.text.toString().isEmpty()) {

            Toast.makeText(this@MainActivity, "Введите логин и пароль", Toast.LENGTH_SHORT).show()
        }
        else{

            val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)

            val savedUsername = sharedPreferences.getString("username", "")
            val savedPassword = sharedPreferences.getString("password", "")


            if (log == savedUsername && pas == savedPassword) {
                val intent = Intent(this@MainActivity, InfoScreen::class.java)
                startActivity(intent)
            }
            else{
                class MyDialogFragment : DialogFragment() {

                    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
                        return activity?.let {
                            val builder = AlertDialog.Builder(it)
                            builder.setTitle("")
                                .setMessage("Пароль неверный")
                                .setCancelable(true)

                                .setNegativeButton("Ок") { dialog, id ->
                                    dialog.cancel()
                                }
                            builder.create()
                        } ?: throw IllegalStateException("Activity cannot be null")
                    }

                }
                val myDialogFragment = MyDialogFragment()
                val manager = supportFragmentManager

                //myDialogFragment.show(manager, "dialog")
                val transaction: FragmentTransaction = manager.beginTransaction()
                myDialogFragment.show(transaction, "dialog")

            }

        }
    }
}
